import { default as Accesibility } from "./components/accesibility";

new Accesibility();
