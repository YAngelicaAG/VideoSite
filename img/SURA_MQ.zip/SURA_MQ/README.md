# SURA-MQ

## Requerimientos:

- Node JS, Instalarlo en: [https://nodejs.org/es/download/](https://nodejs.org/es/download/)

Verificar la instalación de node y npm 

```
node -v
npm-v
```

Instalar dependencias

```
  npm i
```

Correr proyecto

```
  npm run start
```
